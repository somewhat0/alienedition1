//var greenworks = require("../../greenworks");
//var gw = greenworks.init();

nw.Window.open("game/index.html", {
    "width": 960,
    "height": 600,
    "icon": "game/icons/favicon.png"
}, (win) => {

});