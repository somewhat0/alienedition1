(function() {
    //var greenworks = require("../greenworks");
    //greenworks.init();

    //var win = nw.Window.get();
    //win.showDevTools();
})();